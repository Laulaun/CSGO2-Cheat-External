#pragma once

namespace visuals
{
	void run_player_esp();
}