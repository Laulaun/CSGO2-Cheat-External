#pragma once

#include "../atgui.h"

namespace Main
{
	extern bool showWindow;

	extern void RenderWindow();
}