#pragma once

#include "../atgui.h"

namespace Models
{
	void RenderTab();
}